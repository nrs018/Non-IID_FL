python /content/gdrive/MyDrive/FL-NACA/main.py  fedavg /content/gdrive/MyDrive/FL-NACA/config/fedavg0.2.yml > /content/gdrive/MyDrive/FL-NACA/fedavg0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  ccvr /content/gdrive/MyDrive/FL-NACA/config/ccvr0.2.yml > /content/gdrive/MyDrive/FL-NACA/ccvr0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  moon /content/gdrive/MyDrive/FL-NACA/config/moon0.2.yml > /content/gdrive/MyDrive/FL-NACA/moon0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  scaffold /content/gdrive/MyDrive/FL-NACA/config/scaffold0.2.yml > /content/gdrive/MyDrive/FL-NACA/scaffold0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fedprox /content/gdrive/MyDrive/FL-NACA/config/fedprox0.2.yml > /content/gdrive/MyDrive/FL-NACA/fedprox0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fednaca /content/gdrive/MyDrive/FL-NACA/config/fednaca0.2.yml > /content/gdrive/MyDrive/FL-NACA/fednaca0.2.txt
echo "0.2 completed!" > /content/gdrive/MyDrive/FL-NACA/complete0.2.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fedavg /content/gdrive/MyDrive/FL-NACA/config/fedavg0.5.yml > /content/gdrive/MyDrive/FL-NACA/fedavg0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  ccvr /content/gdrive/MyDrive/FL-NACA/config/ccvr0.5.yml > /content/gdrive/MyDrive/FL-NACA/ccvr0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  moon /content/gdrive/MyDrive/FL-NACA/config/moon0.5.yml > /content/gdrive/MyDrive/FL-NACA/moon0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  scaffold /content/gdrive/MyDrive/FL-NACA/config/scaffold0.5.yml > /content/gdrive/MyDrive/FL-NACA/scaffold0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fedprox /content/gdrive/MyDrive/FL-NACA/config/fedprox0.5.yml > /content/gdrive/MyDrive/FL-NACA/fedprox0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fednaca /content/gdrive/MyDrive/FL-NACA/config/fednaca0.5.yml > /content/gdrive/MyDrive/FL-NACA/fednaca0.5.txt
echo "0.5 complete!" > /content/gdrive/MyDrive/FL-NACA/complete0.5.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fedavg /content/gdrive/MyDrive/FL-NACA/config/fedavg1.0.yml > /content/gdrive/MyDrive/FL-NACA/fedavg1.0.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  ccvr /content/gdrive/MyDrive/FL-NACA/config/ccvr1.0.yml > /content/gdrive/MyDrive/FL-NACA/ccvr1.0.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  moon /content/gdrive/MyDrive/FL-NACA/config/moon1.0.yml > /content/gdrive/MyDrive/FL-NACA/moon1.0.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  scaffold /content/gdrive/MyDrive/FL-NACA/config/scaffold1.0.yml > /content/gdrive/MyDrive/FL-NACA/scaffold1.0.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fedprox /content/gdrive/MyDrive/FL-NACA/config/fedprox1.0.yml > /content/gdrive/MyDrive/FL-NACA/fedprox1.0.txt
python /content/gdrive/MyDrive/FL-NACA/main.py  fednaca /content/gdrive/MyDrive/FL-NACA/config/fednaca1.0.yml > /content/gdrive/MyDrive/FL-NACA/fednaca1.0.txt
echo "1.0 complete!" > /content/gdrive/MyDrive/FL-NACA/cinplete1.0.txt
